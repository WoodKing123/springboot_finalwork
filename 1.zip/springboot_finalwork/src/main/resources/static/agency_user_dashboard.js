$(document).ready(function() {
    $("#add-university-form").submit(handleAddUniversitySubmit);
    loadUniversities();
    loadBoundUsers();
    loadAgencyUserInfo();
    loadAgencyProfile();
});

function handleAddUniversitySubmit(e) {
    e.preventDefault();
    console.log("Form submitted");

    var universityData = {
        name: $('#universityName').val(),
        location: $('#universityLocation').val(),
        ranking: $('#universityRanking').val(),
        majors: $('#universityMajors').val(),
        admissionRequirements: $('#universityAdmissionRequirements').val(),
        applicationDeadline: $('#universityApplicationDeadline').val(),
        applicationTips: $('#universityApplicationTips').val()
    };

    $('#submit-button').prop('disabled', true);

    $.ajax({
        url: '/api/universities',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(universityData),
        success: function(response) {
            alert('成功添加大学：' + response.name);
            $('#add-university-form').trigger("reset");
            loadUniversities();
        },
        error: function(xhr) {
            alert('添加学校出错: ' + xhr.responseText);
        },
        complete: function() {
            $('#submit-button').prop('disabled', false);
        }
    });
}

function loadUniversities() {
    $.ajax({
        url: '/api/universities',
        type: 'GET',
        success: function(data) {
            var universityList = $('#university-list');
            universityList.empty();
            data.forEach(function(university) {
                universityList.append('<li class="list-group-item">' + university.name + '</li>');
            });
        },
        error: function(xhr) {
            alert('加载大学列表失败: ' + xhr.responseText);
        }
    });
}

function loadSchools() {
    $.ajax({
        url: '/api/schools',
        type: 'GET',
        success: function(data) {
            $('#schools-list').empty();
            data.forEach(function(school) {
                $('#schools-list').append(`<li class="list-group-item">${school.name}</li>`);
            });
        },
        error: function(error) {
            alert('加载学校列表出错: ' + error.responseText);
        }
    });
}

function loadBoundUsers() {
    $.ajax({
        url: '/api/agencyUsers/userAgencyBindings',
        type: 'GET',
        success: function(data) {
            $('#bound-users-list').empty();
            data.forEach(function(boundUser) {
                $('#bound-users-list').append(`
                    <tr>
                        <td>${boundUser.userId}</td>
                        <td>${boundUser.username}</td>
                        <td>${boundUser.university}</td>
                        <td>${boundUser.document}</td>
                        <td>${getStatusText(boundUser.status)}</td>
                        <td>
                            <button onclick="editStatusClicked(${boundUser.userId})" class="btn btn-warning">编辑状态</button>
                            <button onclick="deleteBinding(${boundUser.userId})" class="btn btn-danger">删除绑定</button>
                        </td>
                    </tr>
                `);
            });
        },
        error: function(error) {
            alert('加载绑定的普通用户列表出错: ' + error.responseText);
        }
    });
}

function editStatusClicked(userId) {
    $.ajax({
        url: '/api/agencyUsers/userAgencyBindings/' + userId,
        type: 'GET',
        success: function(data) {
            $('#userIdToUpdate').val(data.userId);
            $('#applicationStatus').val(data.status);
            // 打开模态框进行编辑
            $('#statusModal').modal('show');
        },
        error: function(error) {
            alert('获取用户状态信息出错: ' + error.responseText);
        }
    });
}

function deleteBinding(userId) {
    if (confirm('您确定要删除这个绑定吗？')) {
        $.ajax({
            url: '/api/agencyUsers/userAgencyBindings/' + userId,
            type: 'DELETE',
            success: function() {
                alert('绑定删除成功');
                loadBoundUsers();
            },
            error: function(error) {
                alert('删除绑定出错: ' + error.responseText);
            }
        });
    }
}

function getStatusText(statusCode) {
    const statusText = {
        '0': '未提交',
        '1': '审核中',
        '2': '审核通过',
        '3': '审核失败'
    };
    return statusText[statusCode] || '未知状态';
}
function loadAgencyUserInfo() {
    var agencyUserId = sessionStorage.getItem('agencyUserId'); // 假设中介用户ID存储在sessionStorage中
    if (agencyUserId) {
        $.ajax({
            url: '/api/agencyUsers/' + agencyUserId,
            type: 'GET',
            success: function(agencyUser) {
                // 填充到前端的DOM中，假设有相应的元素显示信息
                $('#agencyUserName').text(agencyUser.name);
                // ...其他信息...
            },
            error: function(xhr) {
                alert('加载中介用户信息失败: ' + xhr.responseText);
            }
        });
    }
}

function loadAgencyProfile() {
    var agencyUserId = sessionStorage.getItem('userid'); // 获取 'userid'，而不是 'agencyUserId'
    if (agencyUserId) {
        // 继续使用 agencyUserId 进行 AJAX 请求，以加载用户的详细信息
        $.ajax({
            url: '/api/agencyUsers/' + agencyUserId, // 假设这是获取中介用户信息的API
            type: 'GET',
            success: function(agencyUserProfile) {
                // 使用agencyUserProfile数据更新DOM
                // 例如：$('#agency-profile-section').text(agencyUserProfile.name);
            },
            error: function(xhr) {
                console.error('获取中介用户信息失败:', xhr.responseText);
                // 处理错误情况，可能需要给用户反馈或重定向
            }
        });
    } else {
        console.error('无法获取中介用户ID，请确保已登录并且会话存储正确设置');
        // 这里处理用户未登录的逻辑，例如重定向到登录页面
        window.location.href = 'login.html';
    }
}