document.addEventListener('DOMContentLoaded', function() {
    var timelineItems = [
        { date: '2024-03-01', title: '成绩单', description: '准备最近两年的成绩单', position: 'right' },
        { date: '2024-04-01', title: '语言考试', description: '报名参加TOEFL或IELTS考试', position: 'left' },
        // 添加更多时间轴项...
    ];

    var timeline = document.querySelector('.timeline');

    timelineItems.forEach(function(item) {
        var element = document.createElement('li');
        element.classList.add(item.position);
        element.innerHTML = `
            <div class="content">
                <h3>${item.title}</h3>
                <p>${item.description}</p>
            </div>
            <span class="date">${item.date}</span>
        `;
        timeline.appendChild(element);
    });
});
