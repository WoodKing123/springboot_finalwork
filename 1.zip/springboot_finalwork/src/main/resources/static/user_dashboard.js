$(document).ready(function() {
    // 假设用户登录后，用户名被存储在了会话存储中
    var username = sessionStorage.getItem('username'); // 获取存储的用户名

    // 如果会话中没有用户名，则重定向到登录页面
    if (!username) {
        window.location.href = 'login.html';
        return;
    }

    // 获取用户信息并填充到表单
    function fetchUserProfile() {
        $.ajax({
            url: '/api/user/profile/' + encodeURIComponent(username),
            type: 'GET',
            success: function(data) {
                $("#email").val(data.email);
                $("#pwd").val(data.password); // 如果你不打算在前端展示密码，这行应该去掉
            },
            error: function(error) {
                console.error("获取用户信息出错", error);
                alert("无法获取用户信息，请稍后再试。");
            }
        });
    }

// 提交个人信息表单
    $("#profileForm").on("submit", function(e) {
        e.preventDefault();
        var email = $("#email").val();
        var password = $("#pwd").val(); // 如果你不允许通过这个表单更新密码，这行也应该去掉
        $.ajax({
            url: '/api/user/profile/' + encodeURIComponent(username),
            type: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify({ email: email, password: password }), // 确保后端期待这个数据结构
            success: function() {
                alert("个人资料更新成功！");
                // 这里可能需要刷新页面或更新页面上的信息
            },
            error: function(error) {
                console.error("更新资料出错", error);
                alert("无法更新个人资料，请稍后再试。");
            }
        });
    });


    // 提交申请表单
    $("#applicationForm").on("submit", function(e) {
        e.preventDefault();
        // ... 处理文件上传和其他表单数据 ...
    });

    // 获取申请状态
    function fetchApplicationStatus() {
        $.ajax({
            url: '/api/user/status/' + username,
            type: 'GET',
            success: function(data) {
                $("#statusInfo").text(data);
            },
            error: function(error) {
                console.error("获取申请状态出错", error);
                alert("无法获取申请状态，请稍后再试。");
            }
        });
    }

    fetchUserProfile();
    fetchApplicationStatus();
});
