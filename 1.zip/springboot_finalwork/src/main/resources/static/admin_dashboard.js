// admin_dashboard.js

$(document).ready(function() {
    // 加载所有管理员
    function loadAdmins() {
        $.ajax({
            url: '/api/admins',
            type: 'GET',
            success: function(admins) {
                var adminList = $('#admin-list');
                adminList.empty();
                admins.forEach(function(admin) {
                    adminList.append('<tr>' +
                        '<td>' + admin.adminId + '</td>' +
                        '<td>' + admin.username + '</td>' +
                        '<td><button onclick="deleteAdmin(' + admin.adminId + ')" class="btn btn-danger">删除</button></td>' +
                        '</tr>');
                });
            },
            error: function(error) {
                alert('加载管理员列表失败: ' + error.responseText);
            }
        });
    }

    // 加载所有用户
    function loadUsers() {
        $.ajax({
            url: '/api/user',
            type: 'GET',
            success: function(users) {
                var regularUserList = $('#regular-user-list'); // 普通用户列表的 tbody
                var agencyUserList = $('#agency-user-list'); // 中介用户列表的 tbody
                regularUserList.empty();
                agencyUserList.empty();

                users.forEach(function(user) {
                    var row = '<tr>' +
                        '<td>' + (user.userId ? user.userId : '未分配') + '</td>' +
                        '<td>' + user.username + '</td>' +
                        '<td>' + (user.email ? user.email : '无邮箱') + '</td>' +
                        // 添加编辑和删除按钮等其他单元格
                        '<td><button onclick="editUser(' + user.userId + ')" class="btn btn-warning">编辑</button> ' +
                        '<button onclick="deleteUser(' + user.userId + ')" class="btn btn-danger">删除</button></td>' +
                        '</tr>';

                    // 根据 role 分别添加到不同的列表
                    if (user.role === 'user') {
                        regularUserList.append(row);
                    } else if (user.role === 'agency') {
                        agencyUserList.append(row);
                    }
                });
            },
            error: function(error) {
                alert('加载用户列表失败: ' + error.responseText);
            }
        });
    }


    loadUsers();


// 调用加载用户函数
    loadUsers();


    // 当点击编辑按钮时，用用户数据填充模态框
    window.editUser = function(userId) {
        // 确保userId是有效的
        if (userId === null || userId === undefined || userId === "null") {
            alert("无效的用户 ID");
            console.error("无效的用户 ID");
            return;
        }
        // 根据userId获取用户数据
        $.ajax({
            url: '/api/user/' + userId, // 这需要是获取单个用户的正确后端API
            method: 'GET',
            success: function(data) {
                $('#edit-user-id').val(data.userId);
                $('#edit-username').val(data.username);
                $('#edit-email').val(data.email);
                // ...填充其他字段...
                $('#editUserModal').modal('show');
            },
            error: function(error) {
                alert("Error fetching user data: " + error.responseText);
            }
        });
    };

    // 保存更改
    $('#save-user-changes').click(function() {
        var userId = $('#edit-user-id').val();
        var updatedData = {
            username: $('#edit-username').val(),
            email: $('#edit-email').val(),
            // ...其他字段...
        };

        $.ajax({
            url: '/api/user/' + userId, // 这需要是更新单个用户的正确后端API
            method: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify(updatedData),
            success: function(response) {
                $('#editUserModal').modal('hide');
                loadUsers(); // 重新加载用户列表
            },
            error: function(error) {
                alert("Error updating user: " + error.responseText);
            }
        });
    });




    // 提交添加管理员的表单
    $('#add-admin-form').submit(function(e) {
        e.preventDefault();
        var adminData = {
            username: $('#adminUsername').val(),
            password: $('#adminPassword').val()
        };
        $.ajax({
            url: '/api/admins',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(adminData),
            success: function(response) {
                alert('管理员添加成功');
                loadAdmins();
            },
            error: function(error) {
                alert('添加管理员出错: ' + error.responseText);
            }
        });
    });

    // 删除管理员
    window.deleteAdmin = function(adminId) {
        if (confirm('确认删除此管理员吗？')) {
            $.ajax({
                url: '/api/admins/' + adminId,
                type: 'DELETE',
                success: function() {
                    alert('管理员删除成功');
                    loadAdmins();
                },
                error: function(error) {
                    alert('删除管理员出错: ' + error.responseText);
                }
            });
        }
    };

    loadAdmins();
});
