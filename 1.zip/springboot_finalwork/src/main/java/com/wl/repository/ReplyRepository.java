package com.wl.repository;

import com.wl.entity.Reply;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReplyRepository extends JpaRepository<Reply, Long> {
    // 根据帖子ID查询所有相关的回复
    @EntityGraph(attributePaths = {"user"})
    List<Reply> findAllByPostId(Long postId);
}
