package com.wl.repository;

import com.wl.entity.Announcement;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnnouncementRepository extends JpaRepository<Announcement, Long> {
    Announcement findTopByOrderByUpdatedAtDesc();
}
