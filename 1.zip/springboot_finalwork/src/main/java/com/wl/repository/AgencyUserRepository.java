package com.wl.repository;

import com.wl.entity.AgencyUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AgencyUserRepository extends JpaRepository<AgencyUser, Integer> {
    // 这里可以添加特定的查询方法，例如根据userId查询
    AgencyUser findByUserId(Integer userId);
}
