package com.wl.controller;

import com.wl.entity.AgencyUser;
import com.wl.service.AgencyUserService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/agency-users")
public class AgencyUserController {

    @Autowired
    private AgencyUserService agencyUserService;

    @PostMapping
    public ResponseEntity<AgencyUser> createOrUpdateAgencyUser(@RequestBody AgencyUser agencyUser) {
        AgencyUser savedAgencyUser = agencyUserService.createOrUpdateAgencyUser(agencyUser);
        return ResponseEntity.ok(savedAgencyUser);
    }

    // ... 其他端点方法 ...
    @GetMapping("/{userId}/profile")
    public ResponseEntity<?> getAgencyUserProfile(@PathVariable Integer userId) {
        try {
            AgencyUser agencyUserProfile = agencyUserService.getAgencyUserProfile(userId);
            return ResponseEntity.ok(agencyUserProfile);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

}

