package com.wl.controller;

import com.wl.entity.Reply;
import com.wl.entity.User;
import com.wl.service.ReplyService;
import com.wl.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/replies")
public class ReplyController {

    @Autowired
    private ReplyService replyService;
    @Autowired
    private UserService userService;

    // 获取特定帖子的所有回复
    @GetMapping("/post/{postId}")
    public ResponseEntity<List<Reply>> getRepliesByPostId(@PathVariable Long postId) {
        return ResponseEntity.ok(replyService.findAllByPostId(postId));
    }

    // 创建新回复
    @PostMapping
    public ResponseEntity<Reply> createReply(@RequestBody Reply reply, @RequestParam("userId") Long userId) {
        // 根据userId查找User实体
        User user = userService.findById(userId);
        if (user == null) {
            // 如果找不到用户，则返回错误响应
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        // 将User设置到Reply实体中
        reply.setUser(user);
        // 保存Reply实体
        Reply savedReply = replyService.save(reply);
        return ResponseEntity.ok(savedReply);
    }


    // 删除回复
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteReply(@PathVariable Long id) {
        if (replyService.deleteById(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
