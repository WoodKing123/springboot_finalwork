package com.wl.controller;

import com.wl.dto.RegisterDTO;
import com.wl.entity.User;
import com.wl.mapper.UserLoginMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class RegistrationController {

    @Autowired
    private UserLoginMapper userLoginMapper;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterDTO registerDTO) {
        // 检查用户是否已存在
        User existingUser = userLoginMapper.findByUsername(registerDTO.getUsername());
        if (existingUser != null) {
            return ResponseEntity.badRequest().body("用户名已存在");
        }

        // 创建新用户
        User newUser = new User();
        newUser.setUsername(registerDTO.getUsername());
        newUser.setPassword(registerDTO.getPassword()); // 考虑使用加密的密码
        newUser.setEmail(registerDTO.getEmail());
        newUser.setRole(registerDTO.getRole()); // 根据传入的角色设置用户角色

        userLoginMapper.insert(newUser);

        return ResponseEntity.ok().body("用户注册成功");
    }
}
