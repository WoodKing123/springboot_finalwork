package com.wl.controller;

import com.wl.entity.University;
import com.wl.service.UniversityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@RestController
@RequestMapping("/api/universities")
public class UniversityController {
    private static final Logger log = LoggerFactory.getLogger(UniversityController.class);
    private final UniversityService universityService;

    @Autowired
    public UniversityController(UniversityService universityService) {
        this.universityService = universityService;
    }

    @GetMapping("/universities")
    public ResponseEntity<List<University>> getAllUniversities() {
        List<University> universities = universityService.getAllUniversities();
        return ResponseEntity.ok(universities);
    }


    @GetMapping("/{id}")
    public ResponseEntity<University> getUniversityById(@PathVariable Long id) {
        University university = universityService.findById(id);
        return university != null ? ResponseEntity.ok(university) : ResponseEntity.notFound().build();
    }


    @PostMapping
    public ResponseEntity<University> createUniversity(@RequestBody University university) {
        log.info("Attempting to create university: " + university.getName());
        universityService.insert(university);
        log.info("University created: " + university.getName());
        return ResponseEntity.ok(university);
    }

    @PutMapping("/{id}")
    public ResponseEntity<University> updateUniversity(@PathVariable Long id, @RequestBody University university) {
        if (universityService.findById(id) != null) {
            university.setUniversityId(id);
            universityService.update(university);
            return ResponseEntity.ok(university);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUniversity(@PathVariable Long id) {
        if (universityService.findById(id) != null) {
            universityService.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}
