package com.wl.controller;

import com.wl.dto.UserResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.wl.dto.LoginDTO;
import com.wl.entity.User;
import com.wl.mapper.UserLoginMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class LoginController {

    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    private UserLoginMapper userLoginMapper;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDTO loginDTO) {
        try {
            User user = userLoginMapper.findByUsername(loginDTO.getUsername());
            if (user != null && user.getPassword().equals(loginDTO.getPassword())) {
                logger.info("登录成功 for username: {}", loginDTO.getUsername());
                // 这里我们发送了一个UserResponse对象
                UserResponse response = new UserResponse(user.getUsername(), user.getRole(), user.getUserId());
                response.setUserId(user.getUserId()); // 确保设置userId
                response.setUsername(user.getUsername());
                response.setRole(user.getRole());
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("用户名或密码错误");
            }
        } catch (Exception e) {
            logger.error("登录过程中出现异常: ", e);
            return ResponseEntity.status(500).body("服务器错误");
        }
    }
}
