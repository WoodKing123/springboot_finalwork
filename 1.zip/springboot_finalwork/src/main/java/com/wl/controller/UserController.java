package com.wl.controller;

import com.wl.entity.User;
import com.wl.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserController {
    private final UserService userService;
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        User user = userService.findById(id);
        // 添加日志打印，检查 user 是否有 userId
        //System.out.println("Created user with ID: " + user.getUserId());
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<?> createUser(@RequestBody User user) {
        userService.insert(user); // 插入用户
        if (user.getUserId() != null) {
            // 用户ID不为null，表示创建成功
            System.out.println("Created user with ID: " + user.getUserId());
            return ResponseEntity.status(HttpStatus.CREATED).body(user); // 返回状态码201和用户信息
        } else {
            // 用户ID为null，表示创建失败
            String errorMessage = "User creation failed due to ungenerated ID.";
            System.out.println(errorMessage);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMessage); // 返回状态码500和错误信息
        }
    }


    @PutMapping("/profile/{username}")
    public ResponseEntity<User> updateUser(@PathVariable String username, @RequestBody User user) {
        User existingUser = userService.findByUsername(username);
        if (existingUser != null) {
            // 确保您不会覆盖ID，除非您意图更改它
            user.setUserId(existingUser.getUserId()); // 使用现有用户的ID确保更新是针对正确的记录
            userService.update(user);
            return ResponseEntity.ok(user);
        }
        return ResponseEntity.notFound().build();
    }




    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        if (userService.findById(id) != null) {
            userService.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
    // 获取用户个人信息的端点
    @GetMapping("/profile/{username}")
    public ResponseEntity<User> getUserProfile(@PathVariable String username) {
        User user = userService.findByUsername(username);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    // 获取用户申请状态的端点
    @GetMapping("/status/{username}")
    public ResponseEntity<String> getUserApplicationStatus(@PathVariable String username) {
        User user = userService.findByUsername(username);
        return user != null ? ResponseEntity.ok(user.getApplicationStatus()) : ResponseEntity.notFound().build();
    }
    // 绑定中介用户
    @PostMapping("/{userId}/bindAgencyUser")
    public ResponseEntity<?> bindAgencyUser(@PathVariable Long userId, @RequestBody Long agencyUserId) {
        try {
            userService.bindAgencyUser(userId, agencyUserId);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            // 此处应有错误处理
            return ResponseEntity.internalServerError().body("Error binding agency user: " + e.getMessage());
        }
    }

    // 更新申请状态
    @PatchMapping("/{userId}/applicationStatus")
    public ResponseEntity<?> updateApplicationStatus(@PathVariable Long userId, @RequestBody Integer status) {
        try {
            userService.updateApplicationStatus(userId, status);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            // 此处应有错误处理
            return ResponseEntity.internalServerError().body("Error updating application status: " + e.getMessage());
        }
    }
}
