package com.wl.controller;

import com.wl.entity.Application;
import com.wl.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ApplicationController {

    @Autowired
    private ApplicationService applicationService;

    @PostMapping("/applications")
    public ResponseEntity<?> createApplication(@RequestBody Application application) {
        applicationService.addApplication(application);
        return ResponseEntity.ok().body("申请已提交");
    }

    @GetMapping("/applications/{id}")
    public ResponseEntity<Application> getApplication(@PathVariable int id) {
        Application application = applicationService.getApplicationById(id);
        return ResponseEntity.ok(application);
    }

    @PutMapping("/applications")
    public ResponseEntity<?> updateApplication(@RequestBody Application application) {
        applicationService.updateApplication(application);
        return ResponseEntity.ok().body("申请已更新");
    }
}
