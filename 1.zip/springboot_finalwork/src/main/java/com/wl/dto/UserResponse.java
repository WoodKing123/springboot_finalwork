package com.wl.dto;

public class UserResponse {
    private String username;
    private String role;
    private Long userId; // 添加这个字段

    public UserResponse(String username, String role, Long userId) {
        this.username = username;
        this.role = role;
        this.userId = userId; // 设置用户ID
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public String getRole() {
        return role;
    }

    // Setters
    public void setUsername(String username) {
        this.username = username;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
