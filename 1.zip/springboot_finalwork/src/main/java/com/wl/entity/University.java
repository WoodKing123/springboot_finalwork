package com.wl.entity;
/**
 * 海外高校
 */

import lombok.Data;

import java.util.Date;
@Data
public class University {
    private Long universityId;
    private String name;
    private String location;
    private String ranking;
    private String majors;
    private String admissionRequirements;
    private Date applicationDeadline;
    private String applicationTips;

}
