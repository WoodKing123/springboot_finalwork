package com.wl.entity;
/**
 * 管理员信息
 */

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Admin {
    private Long adminId;
    private String username;
    private String password;

}
