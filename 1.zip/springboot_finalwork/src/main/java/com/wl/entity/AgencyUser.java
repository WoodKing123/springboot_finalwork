package com.wl.entity;

import jakarta.persistence.*;

import java.sql.Date;

@Entity
@Table(name = "agency_users")
public class AgencyUser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer agencyUserId;

    @Column(nullable = false)
    private Integer userId;

    private String additionalInfo;

    @Column(nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    // Getters and Setters...

    public Integer getAgencyUserId() {
        return agencyUserId;
    }

    public void setAgencyUserId(Integer agencyUserId) {
        this.agencyUserId = agencyUserId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
}

