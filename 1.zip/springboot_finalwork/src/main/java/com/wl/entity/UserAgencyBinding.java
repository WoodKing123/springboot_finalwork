package com.wl.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserAgencyBinding {
    private Long id;
    private Long userId;
    private Long agencyUserId;
    private Integer status;
    private String username;
    private String university;
    private String document;
}
