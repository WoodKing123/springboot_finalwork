package com.wl.mapper;

import org.apache.ibatis.annotations.Mapper;
import com.wl.entity.Admin;

import java.util.List;

@Mapper
public interface AdminMapper {
    List<Admin> findAll();
    Admin findById(Long id);
    void insert(Admin admin);
    void update(Admin admin);
    void deleteById(Long id);
}
