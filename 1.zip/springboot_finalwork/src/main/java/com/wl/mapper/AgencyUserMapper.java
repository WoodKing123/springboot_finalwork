package com.wl.mapper;

import com.wl.entity.AgencyUser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AgencyUserMapper {
    List<AgencyUser> findAll();
    AgencyUser findById(Long id);
    void insert(AgencyUser agencyUser);
    void update(AgencyUser agencyUser);
    void deleteById(Long id);

    void updateApplicationStatus(@Param("userId") Long userId, @Param("status") Integer status);
}
