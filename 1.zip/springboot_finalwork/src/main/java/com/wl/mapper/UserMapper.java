package com.wl.mapper;

import org.apache.ibatis.annotations.Mapper;
import com.wl.entity.User;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserMapper {
    List<User> findAll();
    User findById(Long id);
    void insert(User user);
    void update(User user);
    void deleteById(Long id);
    @Select("SELECT user_id, username, password, email, application_status, role FROM Users WHERE username = #{username}")
    User findByUsername(String username);
    void bindAgencyUser(@Param("userId") Long userId, @Param("agencyUserId") Long agencyUserId);

    // 添加更新申请状态的方法声明
    void updateApplicationStatus(@Param("userId") Long userId, @Param("status") Integer status);
}
