package com.wl.mapper;

import com.wl.entity.University;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface UniversityMapper {
    List<University> findAll();
    University findById(Long id);
    void insert(University university);
    void update(University university);
    void deleteById(Long id);
}
