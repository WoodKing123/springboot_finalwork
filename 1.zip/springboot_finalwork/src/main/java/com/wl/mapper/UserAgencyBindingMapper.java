package com.wl.mapper;

import com.wl.entity.UserAgencyBinding;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserAgencyBindingMapper {
    void bindUserToAgency(Long userId, Long agencyUserId);
    Integer getApplicationStatus(Long userId);
    void updateApplication(Long userId, String document, Long universityId);
    void bindAgencyUser(@Param("userId") Long userId, @Param("agencyUserId") Long agencyUserId);
    void updateApplicationStatus(@Param("userId") Long userId, @Param("status") Integer status);
    List<UserAgencyBinding> findAll();
    // 可能还需要其他方法...
}

