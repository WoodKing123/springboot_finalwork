package com.wl.mapper;

import com.wl.entity.Application;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ApplicationMapper {
    void insert(Application application);
    Application findById(int id);
    void update(Application application);
}

