package com.wl.mapper;

import com.wl.entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserLoginMapper {
    @Select("SELECT user_id as userId, username, password, email, application_status, role FROM Users WHERE username = #{username}")
    User findByUsername(String username);

    @Insert("INSERT INTO Users (username, password, email, application_status, role) VALUES (#{username}, #{password}, #{email}, 'pending', #{role})")
    void insert(User user);
}


