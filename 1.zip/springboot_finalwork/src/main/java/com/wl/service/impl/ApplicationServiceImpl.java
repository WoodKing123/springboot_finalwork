package com.wl.service.impl;

import com.wl.entity.Application;
import com.wl.mapper.ApplicationMapper;
import com.wl.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApplicationServiceImpl implements ApplicationService {

    @Autowired
    private ApplicationMapper applicationMapper;

    @Override
    public void addApplication(Application application) {
        applicationMapper.insert(application);
    }

    @Override
    public Application getApplicationById(int id) {
        return applicationMapper.findById(id);
    }

    @Override
    public void updateApplication(Application application) {
        applicationMapper.update(application);
    }
}
