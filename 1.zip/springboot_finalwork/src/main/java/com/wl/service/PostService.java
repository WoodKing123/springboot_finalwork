package com.wl.service;

import com.wl.entity.Post;

import java.util.List;
import java.util.Optional;

public interface PostService {
    Post save(Post post);
    List<Post> findAll();
    Optional<Post> findById(Long id);
    Optional<Post> update(Long id, Post post);
    boolean deleteById(Long id);
}
