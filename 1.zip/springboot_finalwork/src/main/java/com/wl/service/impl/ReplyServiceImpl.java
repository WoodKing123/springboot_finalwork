package com.wl.service.impl;

import com.wl.entity.Reply;
import com.wl.repository.ReplyRepository;
import com.wl.service.ReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReplyServiceImpl implements ReplyService {

    @Autowired
    private ReplyRepository replyRepository;

    @Override
    public Reply save(Reply reply) {
        return replyRepository.save(reply);
    }

    @Override
    public List<Reply> findAllByPostId(Long postId) {
        return replyRepository.findAllByPostId(postId);
    }

    @Override
    public boolean deleteById(Long id) {
        return replyRepository.findById(id).map(reply -> {
            replyRepository.delete(reply);
            return true;
        }).orElse(false);
    }
}