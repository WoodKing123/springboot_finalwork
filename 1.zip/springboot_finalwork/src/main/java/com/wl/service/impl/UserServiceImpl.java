package com.wl.service.impl;

import com.wl.entity.User;
import com.wl.mapper.UserMapper;
import com.wl.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    private final UserMapper userMapper;

    //private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    public UserServiceImpl(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public List<User> findAll() {
        return userMapper.findAll();
    }

    @Override
    public User findById(Long id) {
        return userMapper.findById(id);
    }

    @Override
    public void insert(User user) {
        userMapper.insert(user);
        // 检查 user 是否有 userId，如果为 null，可能需要进一步调试
        if (user.getUserId() == null) {
            System.out.println("userId is not generated.");
        } else {
            System.out.println("Inserted user with ID: " + user.getUserId());
        }
    }

    @Override
    public void update(User user) {
        userMapper.update(user);
    }

    @Override
    public void deleteById(Long id) {
        userMapper.deleteById(id);
    }
    @Override
    public User findByUsername(String username) {
        return userMapper.findByUsername(username);
    }
    @Override
    public void bindAgencyUser(Long userId, Long agencyUserId) {
        // 这里假设已经有了UserAgencyBindings表，且表中有对应的记录
        userMapper.bindAgencyUser(userId, agencyUserId);
    }

    @Override
    public void updateApplicationStatus(Long userId, Integer status) {
        // 同样假设已经有了UserAgencyBindings表，且表中有对应的记录
        userMapper.updateApplicationStatus(userId, status);
    }
}
