package com.wl.service.impl;

import com.wl.entity.AgencyUser;
import com.wl.mapper.AgencyUserMapper;
import com.wl.service.AgencyUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AgencyUserServiceImpl implements AgencyUserService {
    private final AgencyUserMapper agencyUserMapper;

    @Autowired
    public AgencyUserServiceImpl(AgencyUserMapper agencyUserMapper) {
        this.agencyUserMapper = agencyUserMapper;
    }

    @Override
    public List<AgencyUser> findAll() {
        return agencyUserMapper.findAll();
    }

    @Override
    public AgencyUser findById(Long id) {
        return agencyUserMapper.findById(id);
    }

    @Override
    public void insert(AgencyUser agencyUser) {
        agencyUserMapper.insert(agencyUser);
    }

    @Override
    public void update(AgencyUser agencyUser) {
        agencyUserMapper.update(agencyUser);
    }

    @Override
    public void deleteById(Long id) {
        agencyUserMapper.deleteById(id);
    }
    public void updateApplicationStatus(Long userId, Integer status) {
        // 实际的更新逻辑，可能是调用一个Mapper方法
        // 例如：
        agencyUserMapper.updateApplicationStatus(userId, status);
    }
}
