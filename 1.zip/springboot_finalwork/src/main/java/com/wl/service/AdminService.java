package com.wl.service;

import com.wl.entity.Admin;

import java.util.List;

public interface AdminService {
    List<Admin> findAll();
    Admin findById(Long id);
    void insert(Admin admin);
    void update(Admin admin);
    void deleteById(Long id);
}
