package com.wl.service;

import com.wl.entity.Application;

public interface ApplicationService {
    void addApplication(Application application);
    Application getApplicationById(int id);
    void updateApplication(Application application);
}
