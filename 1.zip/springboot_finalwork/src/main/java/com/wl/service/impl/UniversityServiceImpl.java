package com.wl.service.impl;

import com.wl.entity.University;
import com.wl.mapper.UniversityMapper;
import com.wl.service.UniversityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UniversityServiceImpl implements UniversityService {
    private final UniversityMapper universityMapper;

    @Autowired
    public UniversityServiceImpl(UniversityMapper universityMapper) {
        this.universityMapper = universityMapper;
    }

    @Override
    public List<University> findAll() {
        return universityMapper.findAll();
    }

    @Override
    public University findById(Long id) {
        return universityMapper.findById(id);
    }

    @Override
    public void insert(University university) {
        universityMapper.insert(university);
    }

    @Override
    public void update(University university) {
        universityMapper.update(university);
    }

    @Override
    public void deleteById(Long id) {
        universityMapper.deleteById(id);
    }
}
