package com.wl.service;

import com.wl.entity.University;

import java.util.List;

public interface UniversityService {
    List<University> findAll();
    University findById(Long id);
    void insert(University university);
    void update(University university);
    void deleteById(Long id);
}