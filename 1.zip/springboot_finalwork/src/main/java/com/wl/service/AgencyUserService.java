package com.wl.service;

import com.wl.entity.AgencyUser;

import java.util.List;

public interface AgencyUserService {
    List<AgencyUser> findAll();
    AgencyUser findById(Long id);
    void insert(AgencyUser agencyUser);
    void update(AgencyUser agencyUser);
    void deleteById(Long id);

    void updateApplicationStatus(Long userId, Integer status);
}
