package com.wl.service;

import com.wl.entity.Announcement;

import java.util.List;
import java.util.Optional;

public interface AnnouncementService {
    Announcement save(Announcement announcement);
    List<Announcement> findAll();
    Announcement findById(Long id);
    Optional<Announcement> findLatestAnnouncement();
    Optional<Announcement> updateAnnouncement(Long id, Announcement announcementDetails);
    boolean deleteById(Long id);
}
