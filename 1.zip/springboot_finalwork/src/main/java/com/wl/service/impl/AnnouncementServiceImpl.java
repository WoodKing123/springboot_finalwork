package com.wl.service.impl;

import com.wl.entity.Announcement;
import com.wl.repository.AnnouncementRepository;
import com.wl.service.AnnouncementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AnnouncementServiceImpl implements AnnouncementService {

    @Autowired
    private AnnouncementRepository announcementRepository;

    @Override
    public Announcement save(Announcement announcement) {
        return announcementRepository.save(announcement);
    }

    @Override
    public List<Announcement> findAll() {
        return announcementRepository.findAll();
    }

    @Override
    public Announcement findById(Long id) {
        return announcementRepository.findById(id).orElse(null);
    }

    @Override
    public Optional<Announcement> updateAnnouncement(Long id, Announcement announcementDetails) {
        return announcementRepository.findById(id)
                .map(announcement -> {
                    // 在这里应用更新，示例代码如下：
                    announcement.setTitle(announcementDetails.getTitle());
                    announcement.setContent(announcementDetails.getContent());
                    // ...更新其他字段...
                    return announcementRepository.save(announcement);
                });
    }

    @Override
    public boolean deleteById(Long id) {
        return announcementRepository.findById(id).map(announcement -> {
            announcementRepository.delete(announcement);
            return true;
        }).orElse(false);
    }

    @Override
    public Optional<Announcement> findLatestAnnouncement() {
        return Optional.ofNullable(announcementRepository.findTopByOrderByUpdatedAtDesc());
    }

}