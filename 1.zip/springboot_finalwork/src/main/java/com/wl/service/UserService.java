package com.wl.service;

import com.wl.entity.User;

import java.util.List;

public interface UserService {
    List<User> findAll();
    User findById(Long id);
    void insert(User user);
    void update(User user);
    void deleteById(Long id);
    // 根据用户名获取用户信息的方法
    User findByUsername(String username);
    // 添加绑定中介用户的方法
    void bindAgencyUser(Long userId, Long agencyUserId);
    // 添加更新申请状态的方法
    void updateApplicationStatus(Long userId, Integer status);
}
