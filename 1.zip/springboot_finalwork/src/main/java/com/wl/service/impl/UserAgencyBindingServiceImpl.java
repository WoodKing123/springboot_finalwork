package com.wl.service.impl;

import com.wl.entity.UserAgencyBinding;
import com.wl.mapper.UserAgencyBindingMapper;
import com.wl.service.UserAgencyBindingService;
import org.apache.ibatis.annotations.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserAgencyBindingServiceImpl implements UserAgencyBindingService {
    private final UserAgencyBindingMapper mapper;
    private UserAgencyBindingMapper userAgencyBindingMapper;

    @Autowired
    public UserAgencyBindingServiceImpl(UserAgencyBindingMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public boolean bindUserToAgency(Long userId, Long agencyUserId) {
        // 实现绑定逻辑
        mapper.bindUserToAgency(userId, agencyUserId);
        return true; // 根据操作结果返回
    }

    @Override
    public Integer getApplicationStatus(Long userId) {
        // 实现获取状态逻辑
        return mapper.getApplicationStatus(userId);
    }

    @Override
    public boolean updateApplication(Long userId, String document, Long universityId) {
        // 实现更新申请逻辑
        mapper.updateApplication(userId, document, universityId);
        return true; // 根据操作结果返回
    }

    // 可能还需要其他方法的实现...
    @Override
    public void bindAgencyUser(Long userId, Long agencyUserId) {
        mapper.bindAgencyUser(userId, agencyUserId); // 使用正确的mapper
    }

    @Override
    public void updateApplicationStatus(Long userId, Integer status) {
        mapper.updateApplicationStatus(userId, status); // 使用正确的mapper
    }

    @Override
    public List<UserAgencyBinding> findAll() {
        return mapper.findAll(); // 使用正确的mapper
    }
}
