package com.wl.service;

import com.wl.entity.Reply;

import java.util.List;

public interface ReplyService {
    Reply save(Reply reply);
    List<Reply> findAllByPostId(Long postId);
    boolean deleteById(Long id);
}