package com.wl.service;

import com.wl.entity.UserAgencyBinding;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserAgencyBindingService {
    boolean bindUserToAgency(Long userId, Long agencyUserId);
    Integer getApplicationStatus(Long userId);
    boolean updateApplication(Long userId, String document, Long universityId);
    // 可能还需要其他方法...
    void bindAgencyUser(Long userId, Long agencyUserId);
    void updateApplicationStatus(Long userId, Integer status);
    List<UserAgencyBinding> findAll();

}

