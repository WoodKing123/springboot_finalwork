package com.wl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.mybatis.spring.annotation.MapperScan;

@SpringBootApplication
//@MapperScan("com.wl.mapper")  // 添加Mapper扫描
public class SpringbootFinalworkApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootFinalworkApplication.class, args);
    }

}
